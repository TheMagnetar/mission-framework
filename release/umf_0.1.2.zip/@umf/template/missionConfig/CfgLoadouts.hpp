/*
 * This file contains standard loadout templates. In order to use them, copy the desired classname
 * and the respective hpp file into missionConfig\CfgLoadouts.hpp and missionConfig\loadouts respectively.
 */
