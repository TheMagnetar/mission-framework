//========================================================================================================//
//================================================  WWII  ================================================//
//========================================================================================================//
class ww2JapanArmy {
    displayName = "WW2 Japan Army";
    #include "loadouts\ww2_japan_army.hpp"
};

class ww2JapanFoliage {
    displayName = "WW2 Japan Foliage";
    #include "loadouts\ww2_japan_foliage.hpp"
};

class ww2JapanNavy {
    displayName = "WW2 Japan Navy";
    #include "loadouts\ww2_japan_navy.hpp"
};
